import time
import random
from collections import deque
import heapq

# Timer utility
def time_operation(func, *args, repeats=5):
    times = []
    for _ in range(repeats):
        start = time.time()
        func(*args)
        end = time.time()
        times.append(end - start)
    avg = sum(times) / repeats
    return avg

# Stack operations using list
def stack_push(stack, values):
    for val in values:
        stack.append(val)

def stack_pop(stack, count):
    for _ in range(count):
        if stack:
            stack.pop()

def stack_peek(stack):
    return stack[-1] if stack else None

# Queue operations using deque
def queue_enqueue(queue, values):
    for val in values:
        queue.append(val)

def queue_dequeue(queue, count):
    for _ in range(count):
        if queue:
            queue.popleft()

def queue_peek(queue):
    return queue[0] if queue else None

# Priority Queue operations using heapq
def pq_push(pq, values):
    for val in values:
        heapq.heappush(pq, val)

def pq_pop(pq, count):
    for _ in range(count):
        if pq:
            heapq.heappop(pq)

def pq_peek(pq):
    return pq[0] if pq else None

def dll_insert_all(dll, values):
    for i, val in enumerate(values):
        dll.insert_at_index(val, i)

def dll_delete_all(dll, values):
    for val in values:
        dll.delete_value(val)

def dll_search_all(dll, values):
    for val in values:
        dll.search(val)


# Doubly Linked List Node & Class

class DNode:
    def __init__(self, data):
        self.data = data
        self.next = None
        self.prev = None

class DoublyLinkedList:
    def __init__(self):
        self.head = None

    def insert_at_index(self, data, index):
        new_node = DNode(data)
        if index == 0:
            if self.head:
                new_node.next = self.head
                self.head.prev = new_node
            self.head = new_node
            return True
        current = self.head
        count = 0
        while current and count < index:
            prev = current
            current = current.next
            count += 1
        if count == index:
            new_node.next = current
            new_node.prev = prev
            prev.next = new_node
            if current:
                current.prev = new_node
            return True
        return False

    def search(self, val):
        current = self.head
        while current:
            if current.data == val:
                return True
            current = current.next
        return False

    def delete_value(self, val):
        current = self.head
        while current:
            if current.data == val:
                if current.prev:
                    current.prev.next = current.next
                else:
                    self.head = current.next
                if current.next:
                    current.next.prev = current.prev
                return True
            current = current.next
        return False

def main():
    #size = 1000
    #size = 10000
    size = 100000
    values = [random.randint(1, 10**6) for _ in range(size)]

    print(f"Benchmarking with {size} values")
    
    # Stack benchmark
    stack = []
    t_push = time_operation(stack_push, stack, values)
    t_peek = time_operation(stack_peek, stack)
    t_pop = time_operation(stack_pop, stack, size)
    print(f"Stack (list) Push: {t_push:.6f} s")
    print(f"Stack (list) Peek: {t_peek:.6f} s")
    print(f"Stack (list) Pop: {t_pop:.6f} s")

    # Queue benchmark
    queue = deque()
    t_enqueue = time_operation(queue_enqueue, queue, values)
    t_peek = time_operation(queue_peek, queue)
    t_dequeue = time_operation(queue_dequeue, queue, size)
    print(f"Queue (deque) Enqueue: {t_enqueue:.6f} s")
    print(f"Queue (deque) Peek: {t_peek:.6f} s")
    print(f"Queue (deque) Dequeue: {t_dequeue:.6f} s")

    # Priority Queue benchmark
    pq = []
    t_push = time_operation(pq_push, pq, values)
    t_peek = time_operation(pq_peek, pq)
    t_pop = time_operation(pq_pop, pq, size)
    print(f"Priority Queue (heapq) Push: {t_push:.6f} s")
    print(f"Priority Queue (heapq) Peek: {t_peek:.6f} s")
    print(f"Priority Queue (heapq) Pop: {t_pop:.6f} s")
    
     ### Doubly Linked List tests
    #dll = []
      
    # Doubly Linked List
    dll = DoublyLinkedList()
    t_insert = time_operation(dll_insert_all, dll, values)
    t_search = time_operation(dll_search_all, dll, values)   # search all values
    t_delete = time_operation(dll_delete_all, dll, values)   # delete all values
    print(f"Doubly Linked List Insert: {t_insert:.6f} s")
    print(f"Doubly Linked List search: {t_search:.6f} s")
    print(f"Doubly Linked List delete: {t_delete:.6f} s")

if __name__ == "__main__":
    main()
