class Graph:
    
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            self.graph[vertex1].append(vertex2)

            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight

            if not self.directed:
                self.graph[vertex2].append(vertex1)
                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    # Remove edge
    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph[vertex1]:
            self.graph[vertex1].remove(vertex2)
            if self.weighted:
                self.weights.pop((vertex1, vertex2), None)

        if not self.directed:
            if vertex2 in self.graph and vertex1 in self.graph[vertex2]:
                self.graph[vertex2].remove(vertex1)
                if self.weighted:
                    self.weights.pop((vertex2, vertex1), None)

    # Remove vertex
    def remove_vertex(self, vertex):
        if vertex in self.graph:
            # Remove all edges pointing to this vertex
            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)
                    if self.weighted:
                        self.weights.pop((v, vertex), None)

            # Remove the vertex itself
            del self.graph[vertex]

            # Remove related weights
            if self.weighted:
                self.weights = {
                    k: v for k, v in self.weights.items()
                    if vertex not in k
                }

    # Print graph
    def print_graph(self):
        for vertex in self.graph:
            if self.weighted:
                edges = [
                    f"{v}({self.weights.get((vertex, v), 0)})"
                    for v in self.graph[vertex]
                ]
                print(f"{vertex} -> {edges}")
            else:
                print(f"{vertex} -> {self.graph[vertex]}")
    # Task 2 Breadth First Search (BFS) Implementation
    def bfs(self, start_vertex):
        visited = []          # store visited order
        queue = []            # queue for BFS

        queue.append(start_vertex)
        visited.append(start_vertex)

        while queue:
            vertex = queue.pop(0)   # FIFO

            for neighbour in self.graph[vertex]:
                if neighbour not in visited:
                    visited.append(neighbour)
                    queue.append(neighbour)

        return visited
    def dfs(self, start_vertex):
        visited = []       
        stack = []        

        stack.append(start_vertex)

        while stack:
            vertex = stack.pop()  # LIFO
            if vertex not in visited:
                visited.append(vertex)
                # Add neighbors to stack 
                for neighbour in reversed(self.graph[vertex]):
                    if neighbour not in visited:
                        stack.append(neighbour)

        return visited
    
    # Helper for DFS-based cycle detection
    def _has_cycle_util(self, vertex, visited, parent):
        visited.add(vertex)
        for neighbour in self.graph[vertex]:
            if neighbour not in visited:
                if self._has_cycle_util(neighbour, visited, vertex):
                    return True
            elif neighbour != parent:
               
                return True
        return False

    # Main function to detect cycles 
    def has_undirected_cycle(self):
        visited = set()
        for vertex in self.graph:
            if vertex not in visited:
                if self._has_cycle_util(vertex, visited, None):
                    return True
        return False
    