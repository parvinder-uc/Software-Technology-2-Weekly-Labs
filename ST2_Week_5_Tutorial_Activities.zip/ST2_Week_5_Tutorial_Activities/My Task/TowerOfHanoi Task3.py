
# TowerOfHanoi.py

# Global variable to count moves
move_count = 0  
def main():
    global move_count
    n = eval(input("Enter number of disks: "))

# Find the solution recursively
    print("The moves are:")
    moveDisks(n, 'A', 'B', 'C')

    print("Total moves:", move_count)

# The function for finding the solution to move n disks
# from fromTower to toTower with auxTower
def moveDisks(n, fromTower, toTower, auxTower):
    global move_count
    
    if n == 1: # Stopping condition
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)
    
main() # Call the main function
