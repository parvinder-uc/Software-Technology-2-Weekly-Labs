from tkinter import *
import math
# KochSnowflake
class KochSnowflake:
    def __init__(self):
     window = Tk()
     window.title("Koch Snowflake")

     self.width = 200
     self.height = 200
     self.canvas = Canvas(window, width=self.width, height=self.height)
     self.canvas.pack()
     frame1 = Frame(window)
     frame1.pack()
     Label(frame1, text="Enter an order: ").pack(side=LEFT)
     self.order = StringVar()
     Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
     Button(frame1, text="Display Sierpinski Triangle",
     command=self.display).pack(side=LEFT)
     window.mainloop()

    def display(self):
        self.canvas.delete("all")
        order = int(self.order.get())

        # Variable margin 50 to fit in 200 by 200 frame
        margin = 50
        # Triangle points
        p1 = [margin, self.height - margin]
        p2 = [self.width - margin, self.height - margin]
        p3 = [self.width / 2, margin]

         # Draw 3 sides
        self.drawKoch(order, p1, p2)
        self.drawKoch(order, p2, p3)
        self.drawKoch(order, p3, p1)

    def drawKoch(self, order, p1, p2):
        if order == 0:
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1])
        else:
            # Divide line into 3 parts
            # line 1
            x1, y1 = p1
            x5, y5 = p2
            # line 2
            x2 = x1 + (x5 - x1) / 3
            y2 = y1 + (y5 - y1) / 3
            # line 3
            x4 = x1 + 2 * (x5 - x1) / 3
            y4 = y1 + 2 * (y5 - y1) / 3
            # Peak of triangle
            dx = x4 - x2
            dy = y4 - y2

            angle = math.radians(60)
            x3 = x2 + dx * math.cos(angle) - dy * math.sin(angle)
            y3 = y2 + dx * math.sin(angle) + dy * math.cos(angle)
            # Recursive calls
            self.drawKoch(order - 1, [x1, y1], [x2, y2])
            self.drawKoch(order - 1, [x2, y2], [x3, y3])
            self.drawKoch(order - 1, [x3, y3], [x4, y4])
            self.drawKoch(order - 1, [x4, y4], [x5, y5])

KochSnowflake()